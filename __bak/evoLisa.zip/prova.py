
from time import time
from random import seed,choice

alphabet = tuple([i for i in range(255)])

def randomize(): seed(time())

def rnd_value():    return choice(alphabet)
def individual():   return  (   
                                (rnd_value(),rnd_value(),rnd_value()),
                                (rnd_value(),rnd_value()),
                                (rnd_value(),rnd_value())
                            )
                            
randomize()

individuals = []

for i in range(10):
    individuals.append(individual())
    
individuals = tuple(individuals)    
print(individuals)
    
